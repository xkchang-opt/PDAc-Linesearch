function [rel_infeas_err,rel_subopt_err,time_period,iter_epoch,oracle,inner]=...
    APDB_c(input,optval,x0,y0,stop_criteria,max_iter)
%************************************************************
% IMPORTANT: optimal solution is used to measure the accuracy of the
% solution found
%
% Written by Erfan Yazdandoost Hamedani, created on 14 November 2018.
%
% The algorithm is specified to solve Quadratic Constrained 
% Quadratic Programming (QCQP) 
%
% The step-sizes are constant according to 
% Theorem 2.1 part (I) in the paper https://arxiv.org/pdf/1803.01401.pdf
%************************************************************
% min_{x} 0.5*x'*A*x+b'*x
% s.t.    0.5*x'*Q_i*x+d_i'*x-c_i<=0, for i=1:m,
%         -10<=x<=10
%************************************************************
    %---------- Unfolding Input ----------%
    A = input{1,1};
    Q = input{2,1};
    b = input{3,1};
    d = input{4,1};
    c = input{5,1};
    lb = input{7,1};
    ub = input{8,1};
    sc = 0;
    [n,~] = size(d);
    optval_rel = max(abs(optval),1);
    %-------------------------------------%
    disp('**********************************************************')
    disp('APDB Convex')
    disp('**********************************************************') 
    epoch=1;
    epoch_counter = 0;
    %------------ step-size Parmeters------%
    eta = 0.7;
    tau = 1e-3;
    gamma = 1;
    sigma_old = gamma*tau;
    tau_old = tau;
    mu = sc;
    %------ Initialization ----------------%
    rel_subopt_err = [];
    rel_infeas_err = [];
    y = y0;
    x = x0;
    iter = 0;
    orc = 0;
    inner = zeros(max_iter,1);
    step = zeros(max_iter,1);
    G_y = grad_y(input,x);
    orc = orc+1;
    tic;
    %---------- Main Algorithm ------------%    
    while iter<max_iter
        iter = iter+1;
        G_y_old = G_y;
        G_y = grad_y(input,x);

        orc = orc+1;
        while true
            sigma = gamma*tau;
            theta = sigma_old/sigma;
            ytild = max(y+sigma*((1+theta)*G_y-theta*G_y_old),0);
            G_x = grad_x(input,x, ytild);
            orc = orc+1;
            xtild = max(min(x-tau*G_x,ub),lb);
            %% linesearch
            E = E_ls(input, tau, sigma, x, xtild, ytild);
            orc = orc+2;
            if E<=0
                step(iter) = tau;
                break;
            else
                inner(iter)=inner(iter)+1;
                tau = tau*eta;
            end
        end
        gamma_old = gamma;
        gamma = gamma*(1+mu*tau);
        tau_new = tau*sqrt(gamma_old/gamma *(1+tau/tau_old));
        %tau_new = tau*sqrt(gamma_old/gamma);
        sigma_old = sigma;
        tau_old = tau;
        tau = tau_new;
        
        y = ytild;
        x = xtild;
        
        if mod(iter,epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter,1) = toc;
            oracle(epoch_counter,1) = orc;
            if isempty(A)
                subopt = b'*x;
            else
                subopt = 0.5*x'*A'*x+b'*x;
            end
            infeas = 0;
            for l=1:n
                if isempty(Q{l,:})
                    infeas = infeas+pos(d(l,:)*x-c(l));
                else
                    infeas = infeas+pos(0.5*x'*Q{l,:}*x+d(l,:)*x-c(l));
                end
            end
            rel_subopt_err(epoch_counter,1) = abs(subopt-optval)/abs(optval_rel);
            rel_infeas_err(epoch_counter,1) = infeas/n;
            iter_epoch(epoch_counter,1) = iter;
            if abs(subopt-optval)/abs(optval_rel)<stop_criteria.f && infeas/n<stop_criteria.inf
                fprintf(...
                    'Iteration    Time    Rel. Infeas error   Rel. Subopt error\n');
                fprintf('%d    %9.4f       %9.1e         %9.1e\n',iter,time_period(epoch_counter),...
                    rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
                return;
            end
        end
    end
    fprintf(...
        'Iteration    Time    Rel. Infeas error   Rel. Subopt error\n');
    fprintf('%d    %9.4f       %9.1e         %9.1e\n',iter,time_period(epoch_counter),...
        rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
end