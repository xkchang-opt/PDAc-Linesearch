function [rel_infeas_err,rel_subopt_err,time_period,iter_epoch,oracle,inner_iter]=...
    GRPDA_c_xy(input,prox,optval,adp_beta,x0,y0,stop_criteria,max_iter)
%************************************************************
% IMPORTANT: optimal solution is used to measure the accuracy of the
% solution found
%
% Written by xiaokai Chang, created on 2022.06.18.
%
% The algorithm is specified to solve Quadratic Constrained 
% Quadratic Programming (QCQP) 
%
% The step-sizes are obtained by linesearch
%************************************************************
% min_{x} 0.5*x'*A*x+b'*x
% s.t.    0.5*x'*Q_i*x+d_i'*x-c_i<=0, for i=1:m,
%         -10<=x<=10
%************************************************************
    %---------- Unfolding Input ----------%
    A = input{1,1};
    Q = input{2,1};
    b = input{3,1};
    d = input{4,1};
    c = input{5,1};
    lb = input{7,1};
    ub = input{8,1};
    beta0 = input{9,1};

    
    [n,~] = size(d);
    optval_rel = max(abs(optval),1);
    %-------------------------------------%
    epoch=1;
    epoch_counter = 0;
    %% ------------ Parmeters------%
    psi = 2; rho = 6/5;
    xi = psi - psi^3*rho/(2*(1+psi));
    w = 2*psi -xi- psi^3*rho/(1+psi);
    mu = 0.7;   % for linesearch 
    
    delta = 1;
    if adp_beta == 1 
        beta  = 1;
        disp('**********************************************************')
        disp('Golden Ratio PDA x-y with adaptive beta')
        disp('**********************************************************') 
    else
        beta  = beta0;
        disp('**********************************************************')
        disp('Golden Ratio PDA x-y with fixed beta')
        disp('**********************************************************')
    end
    
    %------ Initialization ----------------%
    rel_subopt_err = [];
    rel_infeas_err = [];
    y = y0;
    x = x0;
    z = x0;
    iter = 0;
    orc = 0;
    inner_iter = zeros(max_iter,1);
    step = zeros(max_iter,1);
    it_pinf = 0;
    it_dinf = 0;
    G_x = grad_x(input,x,y); 
    %% initial step size tau_0
    x_ = x + rand(size(x)) * 1e-10;
    G_x_ = grad_x(input,x_,y);
    if norm(G_x - G_x_) > 0 
        tau = norm(x - x_)/norm(G_x - G_x_);
    else
        tau = 1e-3;  %% 
    end
    tau_old = tau;
    
    orc = orc+1;
    tic;
    %---------- Main Algorithm ------------%    
    while iter<max_iter
        iter = iter+1;
        %% convex combination
        z = (psi-1)/psi * x +1/psi * z;
        %% compute x
        xtild = max(min(z - tau_old * G_x, ub),lb);
        xdiff = xtild-x; 
        G_y = grad_y(input,xtild); %% G_y = H(x) 
        orc = orc+1;
        tau  = tau_old * rho;
        %% linesearch and only compute y
       while true   
            ytild = prox.f(y + beta*tau * G_y);
            %wtild = (ytild - y)/ (beta*tau) - G_y;
            ydiff = ytild-y;
            orc = orc+2;
            G_x1 = grad_x(input,xtild,ytild);
            Err =  tau_old/xi * norm(G_x- G_x1)^2 ...%% ||theta_n||^2 and Phi_n^y =0
                - 0.999*(norm(ydiff)^2/(tau*beta) + w * delta/tau *norm(xdiff)^2 );  
            if Err <= 0
                step(iter) = tau;
                break;
            else
                inner_iter(iter)=inner_iter(iter)+1;
                tau = tau*mu;  
            end
       end
        delta  = tau_old/tau;
%% adaptive beta and tau      
          pinf = norm(ydiff,1)/(beta*tau);   % or norm(G_y + wtild,1);
          dinf = dist_sub_x(G_x, xtild,lb,ub)/(1+norm(xtild,1));
          
        if adp_beta == 1 
          %dist_sub_w(ytild,wtild)/(1+norm(ytild,1))
          [tau, beta, it_pinf,it_dinf] = adaptive_beta(iter, pinf, dinf, tau, beta, it_pinf,it_dinf);
       end
        
%% update                  
        x = xtild;   y = ytild;   tau_old = tau; G_x = G_x1;
          
        if mod(iter,epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter,1) = toc;
            oracle(epoch_counter,1) = orc;
            if isempty(A)
                subopt = b'*x;
            else
                subopt = 0.5*x'*A'*x+b'*x;
            end
         
            infeas = sum(pos(G_y));
            rel_subopt_err(epoch_counter,1) = abs(subopt-optval)/abs(optval_rel);
            rel_infeas_err(epoch_counter,1) = infeas/n;
            iter_epoch(epoch_counter,1) = iter;
            if ((abs(subopt-optval)/abs(optval_rel)<stop_criteria.f && infeas/n<stop_criteria.inf)...
            && max(pinf,dinf)<1e-6) ||  max(pinf,dinf)<1e-7
                if  adp_beta == 1      
                    fprintf(...
                        'Iteration    Time    Rel. Infeas  Rel. Subopt err   pinf  dinf \n');
                    fprintf('%d    %9.4f     %9.1e     %9.1e    %9.1e    %9.1e\n',iter,time_period(epoch_counter),...
                        rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter),pinf, dinf);
                else
                     fprintf(...
                        'Iteration    Time    Rel. Infeas  Rel. Subopt err \n');
                    fprintf('%d    %9.4f     %9.1e     %9.1e \n',iter,time_period(epoch_counter),...
                        rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
                end
                    
                return;
            end
        end
    end
    if   adp_beta == 1              
        fprintf(...
            'Iteration    Time    Rel. Infeas  Rel. Subopt err   pinf  dinf \n');
        fprintf('%d    %9.4f     %9.1e     %9.1e    %9.1e    %9.1e\n',iter,time_period(epoch_counter),...
            rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter),pinf, dinf);
    else                
        fprintf(...
            'Iteration   Time  Rel.Infeas    Rel.Subopt err\n');
        fprintf('%d    %9.4f    %9.1e     %9.1e  \n',iter,time_period(epoch_counter),...
            rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
    end
    
   
end

 