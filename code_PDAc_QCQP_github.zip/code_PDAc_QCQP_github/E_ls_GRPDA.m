function [Err,R] = E_ls_GRPDA(input, tau, beta,w,delta, x, xtild, y,ytild)
A = input{1,1};
Q = input{2,1};

xdiff = xtild-x;
ydiff = ytild-y;
if isempty(A)
    E = 0;
else
    E = xdiff'*A*xdiff;
end

n = size(Q,1);        
for j=1:n
    if isempty(Q{j,1})
        E = E + 0;  %%  replace Phi_n^y 
    else
        E = E + (xdiff'*Q{j,1}*(xdiff))*ytild(j);  %% replace Phi_n^y 
    end
end
R = norm(xdiff)^2/beta + w * delta *norm(ydiff)^2;
Err = 2 * E  - 0.99*R/tau;
end