function [rel_infeas_err,rel_subopt_err,time_period,iter_epoch,oracle,step]=...
    GRA_c(input,optval,x0,y0,stop_criteria,max_iter)
%************************************************************
% IMPORTANT: optimal solution is used to measure the accuracy of the
% solution found
%
% Written by xiaokai Chang, created on 2022.06.18.
%
% The algorithm is specified to solve Quadratic Constrained 
% Quadratic Programming (QCQP) using golden ratio algorithm 
% proposed by Y. Malitsky
%
% The step-sizes are updating adaptively.
%************************************************************
% min_{x} 0.5*x'*A*x+b'*x
% s.t.    0.5*x'*Q_i*x+d_i'*x-c_i<=0, for i=1:m,
%         -10<=x<=10
%************************************************************
    %---------- Unfolding Input ----------%
    A = input{1,1};
    Q = input{2,1};
    b = input{3,1};
    d = input{4,1};
    c = input{5,1};
    lb = input{7,1};
    ub = input{8,1};
    
    [n,~] = size(d);
    optval_rel = max(abs(optval),1);
    %-------------------------------------%
    disp('**********************************************************')
    disp('Golden Ratio Agorithm for Convex Cases')
    disp('**********************************************************') 
    epoch=1;
    epoch_counter = 0;
    %------------ Parmeters-----------------%
    tau = 1e-3;
    psi = 1.5;
    tau_old = tau;
    rho = 1/psi+1/psi^2;
   
    %------ Initialization ----------------%
    rel_subopt_err = [];
    rel_infeas_err = [];
    y = y0;
    x = x0;
    z_x = x0;
    z_y = y0;
    iter = 0;
    orc = 0;
    step = zeros(max_iter,1);
    tic;
    G_y = grad_y(input,x);
    G_x = grad_x(input,x, y);
    orc = orc+2;
    
    F = [G_x; G_y];
    xy = [x; y];
    
    %---------- Main Algorithm ------------%    
    while iter<max_iter
        iter = iter+1;
        
        z_y = (psi-1)/psi * y +1/psi * z_y;
        z_x = (psi-1)/psi * x +1/psi * z_x;
        
        ytild = max(z_y + tau_old * G_y,0);
        xtild = max(min(z_x - tau_old * G_x,ub),lb);
        
        G_ytild = grad_y(input,xtild); 
        G_xtild = grad_x(input,xtild, ytild);
        
        orc = orc+2;
        Ftild = [G_xtild; G_ytild];
        xy_tild = [xtild; ytild];

        theta = tau/tau_old;
        F_v = norm(Ftild - F);
        if F_v > 0
            tau_v = 0.25* psi* theta /tau * norm(xy_tild - xy)^2/F_v^2;
            tau = min( rho*tau, min(tau_v, 1e+6));
        else
            tau = rho*tau;   
        end
        
     
        step(iter) = tau;
    
       %% updating 
        tau_old = tau;
        x = xtild;        y = ytild;
        G_x = G_xtild;    G_y = G_ytild;
        F = Ftild;        xy = xy_tild;

        if mod(iter,epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter,1) = toc;
            oracle(epoch_counter,1) = orc;
            if isempty(A)
                subopt = b'*x;
            else
                subopt = 0.5*x'*A'*x+b'*x;
            end
         
            infeas = 0;
            for l=1:n
                if isempty(Q{l,:})
                    infeas = infeas+pos(d(l,:)*x-c(l));
                else
                    infeas = infeas+pos(0.5*x'*Q{l,:}*x+d(l,:)*x-c(l));
                end
            end
            rel_subopt_err(epoch_counter,1) = abs(subopt-optval)/abs(optval_rel);
            rel_infeas_err(epoch_counter,1) = infeas/n;
            iter_epoch(epoch_counter,1) = iter;
            if abs(subopt-optval)/abs(optval_rel)<stop_criteria.f && infeas/n<stop_criteria.inf
                fprintf(...
                    'Iteration    Time    Rel. Infeas error   Rel. Subopt error\n');
                fprintf('%d    %9.4f       %9.1e         %9.1e\n',iter,time_period(epoch_counter),...
                    rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
                return;
            end
        end
    end
    fprintf(...
        'Iteration    Time    Rel. Infeas error   Rel. Subopt error\n');
    fprintf('%d    %9.4f       %9.1e         %9.1e\n',iter,time_period(epoch_counter),...
        rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
end