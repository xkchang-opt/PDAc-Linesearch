function y = Plot_main(oracle,rel_subopt,color,fignum,numsim,plot_area)
    cell_leng_oracle = cellfun(@length,oracle,'uni',false);
    cell_maxiter_oracle = cellfun(@max,oracle,'uni',false);
    x_axis = linspace(1, max(cell2mat(cell_maxiter_oracle)),max(cell2mat(cell_leng_oracle)))';
    leng_oracle_max = 1:max(cell2mat(cell_leng_oracle));

    for sim=1:numsim
        int_aux = interp1(oracle{1,sim}, rel_subopt{1,sim}, x_axis, 'nearest', 'extrap');
        ind_f(sim,1) = find(int_aux(1:length(int_aux))>0,1);
        int_rel_subopt{1,sim} = int_aux;
    end
    ind_f_min = min(ind_f);
    for sim=1:numsim
        int_rel_subopt{1,sim}(ind_f_min:ind_f(sim,1)) = int_rel_subopt{1,sim}(ind_f(sim,1));
    end
    color_line = color;
    color_area = color;
    color_area(color_area == 0) = 0.8;
    figure(fignum);
    y_max = max(cell2mat(int_rel_subopt),[],2);
    y_min = min(cell2mat(int_rel_subopt),[],2);
    
    y_max(y_max==0) = 1e-9;
    y_min(y_min==0) = 1e-9;
    if plot_area == 1
       fill([x_axis; x_axis(end:-1:1)],[y_max; y_min(end:-1:1)],color_area,'EdgeColor',[1 1 1]);  
    end
    hold 'on'
    y = semilogy(x_axis, mean(cell2mat(int_rel_subopt),2), 'color', ...
        color_line, 'LineWidth', 1.5);
    set(gca,'Yscale','log');
    %set(gca,'Xscale','log');
    
end