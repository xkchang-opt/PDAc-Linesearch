function dist = dist_sub_x(G_x, xtild, lb,ub)

a = G_x(xtild < ub & xtild > lb);
b = G_x(xtild >= ub);
c = G_x(xtild <= lb);

b = b(b>0);
c = c(c<0);

dist = norm([a; b; c],1);

end