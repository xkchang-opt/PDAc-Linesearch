function dist =dist_sub_w(y,w)

a = y(w > 0);
b = y(w <= 0);
b = b(b<0);

dist = norm([a; b],1);

end