function G_y = grad_y(input,x)

Q = input{2,1};
d = input{4,1};
c = input{5,1};
n = size(Q,1);
G_y = zeros(n,1);
for j=1:n
%     j
%     size(x)
%     size(Q{j,1})
    if isempty(Q{j,1})
        G_y(j,1) = d(j,:)*x-c(j); 
    elseif isempty(d)
        G_y(j,1) = 0.5*x'*Q{j,1}*x; 
    else
       G_y(j,1) = 0.5*x'*Q{j,1}*x+d(j,:)*x-c(j); 
    end
end
end
