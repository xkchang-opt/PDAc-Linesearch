function dist = dist_sub_l1(G_x, xtild, eta)

a = G_x(xtild > 0 )+ eta;
b = G_x(xtild < 0) - eta;
c = G_x(xtild == 0);
c1 = c(c > eta) + eta;
c2 = c(c < -eta) - eta;


dist = norm([a; b; c1; c2],1);

end