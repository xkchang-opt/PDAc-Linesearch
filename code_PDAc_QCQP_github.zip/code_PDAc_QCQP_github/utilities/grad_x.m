function G_x = grad_x(input,x, ytild)

A = input{1,1};
Q = input{2,1};
b = input{3,1};
d = input{4,1};

n = size(Q);
if isempty(A)
    G_x = b;
else    
    G_x = A*x+b;
end
    for j=1:n
        if isempty(Q{j,1})
            G_x = G_x+d(j,:)'*ytild(j);
        elseif isempty(d)
            G_x = G_x+Q{j,1}*x*ytild(j);
        else
            G_x = G_x+(Q{j,1}*x+d(j,:)')*ytild(j);
        end
    end
end
