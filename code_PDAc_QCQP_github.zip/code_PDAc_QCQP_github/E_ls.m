function E = E_ls(input, tau, sigma, x, xtild, ytild)
A = input{1,1};
Q = input{2,1};
d = input{4,1};

xdiff = xtild-x;
if isempty(A)
    E = 0;
else
    E = xdiff'*A*xdiff;
end

aux = 0;
n = size(Q,1);
for j=1:n
    if isempty(Q{j,1})
        E = E+0;
        aux = aux+norm(d(j,:)*(xdiff))^2;
    elseif isempty(d)
        E = E+((xdiff)'*Q{j,1}*(xdiff))*ytild(j);
        aux = aux+norm(0.5*xtild'*Q{j,1}*xtild-0.5*x'*Q{j,1}*x)^2;
    else
        E = E+((xdiff)'*Q{j,1}*(xdiff))*ytild(j);
        aux = aux+norm(0.5*xtild'*Q{j,1}*xtild-0.5*x'*Q{j,1}*x+d(j,:)*(xdiff))^2;
    end
end
E = E-norm(xdiff)^2/(2*tau)+(sigma)*aux/2;

end