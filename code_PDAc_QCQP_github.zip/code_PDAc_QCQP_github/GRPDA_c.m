function [rel_infeas_err,rel_subopt_err,time_period,iter_epoch,oracle,inner_iter,max_pd]=...
    GRPDA_c(input,prox,optval,adp_beta,x0,y0,stop_criteria,max_iter)
%************************************************************
% IMPORTANT: optimal solution is used to measure the accuracy of the
% solution found
%
% Written by xiaokai Chang, created on 2022.06.18.
%
% The algorithm is specified to solve Quadratic Constrained 
% Quadratic Programming (QCQP) 
%
% The step-sizes are obtained by linesearch
%************************************************************
% min_{x} 0.5*x'*A*x+b'*x
% s.t.    0.5*x'*Q_i*x+d_i'*x-c_i<=0, for i=1:m,
%         -10<=x<=10
%************************************************************
    %---------- Unfolding Input ----------%
    A = input{1,1};
    Q = input{2,1};
    b = input{3,1};
    d = input{4,1};
    c = input{5,1};
    lb = input{7,1};
    ub = input{8,1};
    beta0 = input{9,1};
    max_pd = [];
    
    [n,~] = size(d);
    optval_rel = max(abs(optval),1);
    %-------------------------------------%
    epoch=1;
    epoch_counter = 0;
    %% ------------ Parmeters------%
    psi = 2;  rho = 6/5;
    xi = psi - psi^3*rho/(2*(1+psi));
    w = 2*psi -xi- psi^3*rho/(1+psi);
    mu = 0.7;   % for linesearch 
    
    delta = 1;
    if adp_beta == 1
        beta  = 1;
        disp('**********************************************************')
        disp('Golden Ratio PDA y-x with adaptive beta')
        disp('**********************************************************') 
    else
        beta  = beta0;
        disp('**********************************************************')
        disp('Golden Ratio PDA y-x with fixed beta')
        disp('**********************************************************')
    end
        
    %------ Initialization ----------------%
    rel_subopt_err = [];
    rel_infeas_err = [];
    y = y0;
    x = x0;
    z = y0;
    iter = 0;
    orc = 0;
    inner_iter = zeros(max_iter,1);
    step = zeros(max_iter,1);
    it_pinf = 0;
    it_dinf = 0;
    G_y = grad_y(input,x);  %% H(y) = G_y
    %% initial step size tau_0
    x_ = x + rand(size(x)) * 1e-10;
    G_y_ = grad_y(input,x_);
    if norm(G_y - G_y_) > 0 
        tau = norm(x - x_)/norm(G_y - G_y_);
    else
        tau = 1e-3;  %% 
    end
    tau_old = tau;
   
    orc = orc+1;
    tic;
    %---------- Main Algorithm ------------%    
    while iter<max_iter
        iter = iter+1;
        %% convex combination
        z = (psi-1)/psi * y +1/psi * z;
        %% compute y
        ytild = prox.f(z + tau_old * G_y);
        wtild = (ytild - z)/tau_old - G_y;

        G_x = grad_x(input,x, ytild);
        orc = orc+1;
        tau  = tau_old * rho;
        %% linesearch and compute x
       while true   
            xtild = max(min(x - beta*tau * G_x, ub),lb);
            G_y1 = grad_y(input,xtild);
            Err = E_ls_GRPDA(input, tau, beta,w,delta, x, xtild, y,ytild);
            orc = orc+2;
            Err = Err + tau_old/xi * norm(G_y- G_y1)^2;  %% ||theta_n||^2
            if Err <= 0
                step(iter) = tau;
                break;
            else
                inner_iter(iter)=inner_iter(iter)+1;
                tau = tau*mu;     
            end
       end
        delta  = tau_old/tau;
%% adaptive beta and tau      
          pinf = norm(G_y + wtild,1);
          dinf = dist_sub_x(G_x, xtild,lb,ub)/(1+norm(xtild,1));
          max_pd = [max_pd max(pinf,dinf)];
          
       if adp_beta == 1
          %dist_sub_w(ytild,wtild)/(1+norm(ytild,1))
          [tau, beta, it_pinf,it_dinf] = adaptive_beta(iter, pinf, dinf, tau, beta, it_pinf,it_dinf);
       end
        
%% update                  
        x = xtild;   y = ytild;   tau_old = tau; G_y = G_y1;
          
        if mod(iter,epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter,1) = toc;
            oracle(epoch_counter,1) = orc;
            if isempty(A)
                subopt = b'*x;
            else
                subopt = 0.5*x'*A'*x+b'*x;
            end
         
            infeas = sum(pos(G_y));

            rel_subopt_err(epoch_counter,1) = abs(subopt-optval)/abs(optval_rel);
            rel_infeas_err(epoch_counter,1) = infeas/n;
            iter_epoch(epoch_counter,1) = iter;
            if ((abs(subopt-optval)/abs(optval_rel)<stop_criteria.f && infeas/n<stop_criteria.inf) ...
                    && max(pinf,dinf)<1e-6) || max(pinf,dinf)<1e-7
                if  adp_beta == 1      
                    fprintf(...
                        'Iteration    Time    Rel. Infeas  Rel. Subopt err   pinf  dinf \n');
                    fprintf('%d    %9.4f     %9.1e     %9.1e    %9.1e    %9.1e\n',iter,time_period(epoch_counter),...
                        rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter),pinf, dinf);
                else
                     fprintf(...
                        'Iteration    Time    Rel. Infeas  Rel. Subopt err \n');
                    fprintf('%d    %9.4f     %9.1e     %9.1e \n',iter,time_period(epoch_counter),...
                        rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
                end
                    
                return;
            end
        end
    end
    if   adp_beta == 1              
        fprintf(...
            'Iteration    Time    Rel. Infeas  Rel. Subopt err   pinf  dinf \n');
        fprintf('%d    %9.4f     %9.1e     %9.1e    %9.1e    %9.1e\n',iter,time_period(epoch_counter),...
            rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter),pinf, dinf);
    else                
        fprintf(...
            'Iteration   Time  Rel.Infeas    Rel.Subopt err\n');
        fprintf('%d    %9.4f    %9.1e     %9.1e  \n',iter,time_period(epoch_counter),...
            rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
    end
    
   
end

 