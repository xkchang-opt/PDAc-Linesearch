% Written by Xiaokai Chang, created on 14 July 2023.
% solve Quadratic Constrained Quadratic Programming (QCQP) 
%************************************************************
% min_{x} 0.5*x'*A*x+b'*x
% s.t.    0.5*x'*Q_i*x+d_i'*x-c_i<=0, for i=1:m,
%         -10<=x<=10
%************************************************************

clear all;
clc;
seed = 123;
% rng(seed,'twister');
rand('seed',seed);
randn('seed',seed);
addpath('utilities');

numsim = 10;
n = 10;
m = 5e2;
x0 = rand(m,1);
y0 = zeros(n,1);
for sim=1:numsim
    sim
    S = orth(randn(m,m));
    D = (rand(m-1,1)*100);
    % controlling strong convexity and Lip constants
    A = S'*diag([D;1e-10])*S; % for merely convex scenario
    b = randn(m,1);
    sc = min(eig(A));
    if sc<1e-8
        sc = 0;
    end
    d = randn(n,m);
    Q = cell(n,1);
    for j=1:n
        S = orth(randn(m,m));
        D = (rand(m-1,1)*100);
        Q{j,1} = S'*diag([D;1e-10])*S;
    end
    c = rand(n,1);
    lb = -10*ones(m,1);
    ub = 10*ones(m,1);
    %------------- CVX ------------------%
    disp('starting cvx...');
    tic;
    cvx_begin quiet
        cvx_precision high
        variable xstar(m,1)
        dual variable ystar{n}
        constraint = cvx(zeros(n,1));
        for l=1:n
            constraint(l) = 0.5*xstar'*Q{l,:}*xstar+d(l,:)*xstar-c(l);
        end
        minimize(0.5*xstar'*A*xstar+b'*xstar);
        subject to
            for l=1:n
                constraint(l) <= 0 : ystar{l};
            end
            xstar <= 10*ones(m,1);
            xstar >= -10*ones(m,1);
    cvx_end
    time_mosek = toc;
    display(time_mosek);
   optval = cvx_optval;
    %---------------------------------------------%
    beta0 = 30;
    input = {A;Q;b;d;c;sc;lb;ub;beta0}; 
    %----------- simulations ---------------------%
    max_iter = 5e4;
    epsilon.inf = 1e-8;  %% for  constraint violations
    epsilon.f = 1e-8;    %% for function value residuals
    prox.f = @(y) max(y,0);
    % controlling adaptive step sizes
    adp_beta = 1;  %% 1-for adaptively update beta, 0-for else beta0 = 50
    %% convex combination in x-subproblem, linesearch condition is easy to check, Phi_n^y = 0
     para_ls.M = 5;   para_ls.nu = 0.9;     para_ls.eta = 0.9;
     [rel_infeas_Ga{1,sim},rel_subopt_Ga{1,sim},time_period_Ga{1,sim}...
           ,iter_epoch_Ga{1,sim},oracle_Ga{1,sim},inner_iterGa,max_pd]...
     =GRPDA_c_xy(input,para_ls,prox,optval,adp_beta,x0,y0,epsilon,max_iter);
fprintf('Number of extra linesearch trials in PDAc-L: %d\n',sum(inner_iterGa));

%% golden ratio algorithm (aGRAAL) by Malitsky for solving variational inequality
         [rel_infeas_GRA{1,sim},rel_subopt_GRA{1,sim},time_period_GRA{1,sim}...
             ,iter_epoch_GRA{1,sim},oracle_GRA{1,sim},step]=GRA_c(input,optval,x0,y0,epsilon,max_iter);
%    
%% PDA with backtracking (PDB) by Hamedani and Aybat
        [rel_infeas{1,sim},rel_subopt{1,sim},time_period{1,sim}...
           ,iter_epoch{1,sim},oracle{1,sim},inner_iterP]=APDB_c(input,optval,x0,y0,epsilon,max_iter); 
       fprintf('Number of extra linesearch trials in APDB: %d\n',sum(inner_iterP));
   
end

% fprintf('%d&%10.1f&%d &%10.1f&%d&%d&%10.1f&%d\\\\ \n',...
%          iter_epoch_GRA{1,1}(end), time_period_GRA{1,1}(end),iter_epoch{1,1}(end), time_period{1,1}(end),...
%           sum(inner_iterP),iter_epoch_Ga{1,1}(end), time_period_Ga{1,1}(end),...
%           sum(inner_iterGa));
%% Plotting the average of simulations
plot_area = 1;
p3 = Plot_main(iter_epoch_GRA,rel_subopt_GRA,[0 1 1],1,numsim, plot_area);
p1 = Plot_main(iter_epoch,rel_subopt,[1 0 0],1,numsim, plot_area);
p4 = Plot_main(iter_epoch_Ga,rel_subopt_Ga,[0 0 1],1,numsim, plot_area);

grid 'on'
xlabel({'Iterations'},'Interpreter','latex','FontSize',14);
ylabel({'$e_{\mbox{obj}}(x_n)$'},'Interpreter','latex','FontSize',14);
legend([p3 p1 p4],{'aGRAAL','PDB','PDAc-L'});
set(gca,'FontSize',14,'LineWidth',1);


p3 = Plot_main_time(time_period_GRA,rel_subopt_GRA,[0 1 1],2,numsim, plot_area);
p1 = Plot_main_time(time_period,rel_subopt,[1 0 0],2,numsim, plot_area);
p4 = Plot_main_time(time_period_Ga,rel_subopt_Ga,[0 0 1],2,numsim, plot_area);
grid 'on'
xlabel({'Time(second)'},'Interpreter','latex','FontSize',14);
ylabel({'$e_{\mbox{obj}}(x_n)$'},'Interpreter','latex','FontSize',14);
legend([p3 p1 p4],{'aGRAAL','PDB','PDAc-L'});
set(gca,'FontSize',14,'LineWidth',1);

p3 = Plot_main(iter_epoch_GRA,rel_infeas_GRA,[0 1 1],3,numsim, plot_area);
p1 = Plot_main(iter_epoch,rel_infeas,[1 0 0],3,numsim, plot_area);
p4 = Plot_main(iter_epoch_Ga,rel_infeas_Ga,[0 0 1],3,numsim, plot_area);
grid 'on'
xlabel({'Iterations'},'Interpreter','latex','FontSize',14);
ylabel({'$e_{\mbox{con}}(x_n)$'},'Interpreter','latex','FontSize',14);
legend([p3 p1 p4],{'aGRAAL','PDB','PDAc-L'});
set(gca,'FontSize',14,'LineWidth',1);

p3 = Plot_main_time(time_period_GRA,rel_infeas_GRA,[0 1 1],4,numsim, plot_area);
p1 = Plot_main_time(time_period,rel_infeas,[1 0 0],4,numsim, plot_area);
p4 = Plot_main_time(time_period_Ga,rel_infeas_Ga,[0 0 1],4,numsim, plot_area);
grid 'on'
xlabel({'Time(second)'},'Interpreter','latex');
ylabel({'$e_{\mbox{con}}(x_n)$'},'Interpreter','latex','FontSize',14);
legend([p3 p1 p4],{'aGRAAL','PDB','PDAc-L'});
set(gca,'FontSize',14,'LineWidth',1);
