function [rel_infeas_err,rel_subopt_err,time_period,iter_epoch,oracle,inner_iter]=...
    GRPDA_c_xy_acc(input,prox,optval,x0,y0,stop_criteria,max_iter)
%************************************************************
% IMPORTANT: optimal solution is used to measure the accuracy of the
% solution found
%
% Written by xiaokai Chang, created on 2022.06.18.
%
% The algorithm is specified to solve Quadratic Constrained 
% Quadratic Programming (QCQP) 
%
% The step-sizes are obtained by linesearch
%************************************************************
% min_{x} 0.5*x'*A*x+b'*x
% s.t.    0.5*x'*Q_i*x+d_i'*x-c_i<=0, for i=1:m,
%         -10<=x<=10
%************************************************************
    %---------- Unfolding Input ----------%
    A = input{1,1};
    Q = input{2,1};
    b = input{3,1};
    d = input{4,1};
    c = input{5,1};
    gamma_g = input{6,1};
    lb = input{7,1};
    ub = input{8,1};
    beta0 = input{9,1};
    input{1,1} = A-gamma_g*eye(size(A));

    
    [n,~] = size(d);
    optval_rel = max(abs(optval),1);
    %-------------------------------------%
    epoch=1;
    epoch_counter = 0;
    %% ------------ Parmeters------%
    psi = 2; rho = 6/5;
    xi = psi - psi^3*rho/(2*(1+psi));
    w = 2*psi -xi- psi^3*rho/(1+psi);
    mu = 0.7;   % for linesearch 
    
    delta = 1;
    beta_old  = beta0;
    disp('**********************************************************')
    disp('Golden Ratio PDA x-y with acceleration')
    disp('**********************************************************')    
    %------ Initialization ----------------%
    rel_subopt_err = [];
    rel_infeas_err = [];

    y = y0;   x = x0;   z = x0;
    iter = 0;   orc = 0;
    inner_iter = zeros(max_iter,1);
    step = zeros(max_iter,1);
    G_x = grad_x(input,x,y); 
    %% initial step size tau_0
    x_ = x + rand(size(x)) * 1e-10;
    G_x_ = grad_x(input,x_,y);
    if norm(G_x - G_x_) > 0 
        tau = norm(x - x_)/norm(G_x - G_x_);
    else
        tau = 1e-3;  %% 
    end
    tau_old = tau;
    
    orc = orc+1;
    tic;
    %---------- Main Algorithm ------------%    
    while iter<max_iter
        iter = iter+1;
        %% convex combination
        z = (psi-1)/psi * x +1/psi * z;
        %% compute x
        xtild = max(min((z - tau_old * G_x)/(1+tau_old*gamma_g), ub),lb);
        xdiff = xtild-x; 
        G_y = grad_y(input,xtild); %% G_y = H(x) 
        orc = orc+1;
        %% update beta
        om = (psi-rho)/(psi + rho*gamma_g*tau_old);
        beta = (1 + gamma_g * om *tau_old)* beta_old;
        %% linesearch and only compute y
       tau  = min(tau_old * rho, 1e+6);
       while true   
            ytild = prox.f(y + beta*tau * G_y);
            %wtild = (ytild - y)/ (beta*tau) - G_y;
            ydiff = ytild-y;
            orc = orc+2;
            G_x1 = grad_x(input,xtild,ytild);
            k_n = w * delta + gamma_g * tau_old;
            R = norm(ydiff)^2/beta + beta_old/beta*k_n *norm(xdiff)^2; 
            Err =  tau_old/xi * norm(G_x- G_x1)^2- R/tau; %% ||theta_n||^2 and Phi_n^y =0
                  
            if Err <= 0
                step(iter) = tau;
                break;
            else
                inner_iter(iter)=inner_iter(iter)+1;
                tau = tau*mu;  
            end
       end
        delta  = tau_old/tau; 
%         pinf = norm(ydiff,1)/(beta*tau)    % or norm(G_y + wtild,1);
%         dinf = dist_sub_x(G_x, xtild,lb,ub)/(1+norm(xtild,1)) 
%% update                  
        x = xtild; y = ytild; tau_old = tau; G_x = G_x1; beta_old = beta;    
        if mod(iter,epoch) == 0
            epoch_counter = epoch_counter+1;
            time_period(epoch_counter,1) = toc;
            oracle(epoch_counter,1) = orc;
            if isempty(A)
                subopt = b'*x;
            else
                subopt = 0.5*x'*A'*x+b'*x;
            end
         
            infeas = sum(pos(G_y));
            rel_subopt_err(epoch_counter,1) = abs(subopt-optval)/abs(optval_rel);
            rel_infeas_err(epoch_counter,1) = infeas/n;
            iter_epoch(epoch_counter,1) = iter;
            if abs(subopt-optval)/abs(optval_rel)<stop_criteria.f && infeas/n<stop_criteria.inf
            %if infeas/n<stop_criteria.inf
                     fprintf(...
                        'Iteration    Time    Rel. Infeas  Rel. Subopt err \n');
                    fprintf('%d    %9.4f     %9.1e     %9.1e \n',iter,time_period(epoch_counter),...
                        rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
                    
                return;
            end
        end
    end       
        fprintf(...
            'Iteration   Time  Rel.Infeas    Rel.Subopt err\n');
        fprintf('%d    %9.4f    %9.1e     %9.1e  \n',iter,time_period(epoch_counter),...
            rel_infeas_err(epoch_counter),rel_subopt_err(epoch_counter));
    
   
end

 